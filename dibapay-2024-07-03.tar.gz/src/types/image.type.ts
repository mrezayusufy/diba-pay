interface Image {
  id: number | null;
  original: string;
  file_name: string;
  thumbnail: string;
}
export type { Image };