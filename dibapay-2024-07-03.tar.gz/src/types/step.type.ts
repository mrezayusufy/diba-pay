interface StepType {
  index: number;
  label: string;
  status: boolean; 
}
export {type StepType };