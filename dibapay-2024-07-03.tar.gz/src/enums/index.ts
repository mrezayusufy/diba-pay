export enum StatusEnum {
  idle = 0,
  pending = 1,
  verified = 2,
  success = 3,
  failure = 4,
}
export enum Category {
  gold = 1,
  silver = 0
}