const Cart = () => {
  return <div>cart</div>
}
export default Cart;