export { api } from "./api/api"
export { fetchProducts } from "./api/products";
export { fetchCategories } from "./api/categories";