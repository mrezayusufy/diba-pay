function Welcome() {
  return (
    <div>
      خوش آمدید      
    </div>
  )
}

export default Welcome
