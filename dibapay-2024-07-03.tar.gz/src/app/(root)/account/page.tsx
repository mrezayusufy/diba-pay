
function Page() {
  return (
    <div>
      Account
    </div>
  )
}

export default Page
