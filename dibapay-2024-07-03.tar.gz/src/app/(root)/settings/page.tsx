export default function Page(){
  return <div>تنظیمات</div>
}