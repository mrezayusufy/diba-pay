import React from "react";

export default function Loading(){
  return <p> درحال بارگزاری
    <img src="/logo-diba-dark.svg"/>
  </p>
}